﻿import 'package:flutter/material.dart';

class WeatherCenterResults extends StatefulWidget {
  const WeatherCenterResults({
    super.key,
    required this.rows,
    this.showDetails = true,
  });

  final List<Map<String, dynamic>> rows;
  final bool showDetails;

  @override
  State<WeatherCenterResults> createState() => _WeatherCenterResultsState();
}

class _WeatherCenterResultsState extends State<WeatherCenterResults> {
  static const _kBg = Color(0xFF0E0E0E);
  static const _kPanel = Color(0xFF141414);
  static const _kOrange = Color(0xFFFF6A00);

  String _selectedThreatFilter = 'All';

  // All threat logic is local, computed on the front end.
  String _levelOf(Map<String, dynamic> row) {
    final probRaw = row['Wind Outage Probability %'];
    final customersRaw = row['Predicted Customers Out'];
    final popRaw = row['Population'];

    double prob;
    if (probRaw is num) {
      prob = probRaw.toDouble();
    } else {
      prob = double.tryParse(probRaw?.toString() ?? '') ?? 0;
    }

    int customers;
    if (customersRaw is num) {
      customers = customersRaw.toInt();
    } else {
      customers = int.tryParse(customersRaw?.toString() ?? '') ?? 0;
    }

    int population;
    if (popRaw is num) {
      population = popRaw.toInt();
    } else {
      population = int.tryParse(popRaw?.toString() ?? '') ?? 0;
    }

    // Basic, local, SPP-style threat rules.
    // You can tweak these thresholds later without touching the backend.
    if (prob >= 45 || customers >= 25000) {
      return 'Level 3';
    }
    if (prob >= 20 || customers >= 5000) {
      return 'Level 2';
    }
    if (prob >= 12 || customers > 0) {
      return 'Level 1';
    }
    return 'Level 0';
  }

  List<Map<String, dynamic>> get filteredRows {
    if (_selectedThreatFilter == 'All') {
      return widget.rows;
    }

    return widget.rows.where((row) {
      final level = _levelOf(row);
      return level == _selectedThreatFilter;
    }).toList();
  }

  @override
  Widget build(BuildContext context) {
    final total = widget.rows.length;
    final visible = filteredRows.length;

    // Debug prints so we can see what is really happening without changing UX.
    // These will show in your Flutter log:
    //   RESULTS SCREEN total rows=5 visible=5 (for example)
    // This is just for you, it does not change layout.
    // ignore: avoid_print
    print('RESULTS SCREEN total rows=$total visible=$visible');

    return Scaffold(
      backgroundColor: _kBg,
      appBar: AppBar(
        backgroundColor: const Color(0xFF121212),
        elevation: 0,
        title: const Text(
          'Results',
          style: TextStyle(
            fontWeight: FontWeight.w700,
            letterSpacing: 0.3,
          ),
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: widget.rows.isEmpty
            ? const Center(
                child: Text(
                  'No results returned from backend.',
                  style: TextStyle(color: Colors.white70),
                ),
              )
            : Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      const Text(
                        'Threat:',
                        style: TextStyle(
                          color: Colors.white70,
                          fontSize: 14,
                        ),
                      ),
                      const SizedBox(width: 8),
                      Container(
                        padding:
                            const EdgeInsets.symmetric(horizontal: 12),
                        decoration: BoxDecoration(
                          color: _kPanel,
                          borderRadius: BorderRadius.circular(8),
                          border: Border.all(color: _kOrange, width: 1),
                        ),
                        child: DropdownButton<String>(
                          value: _selectedThreatFilter,
                          dropdownColor: _kPanel,
                          underline: const SizedBox(),
                          iconEnabledColor: _kOrange,
                          items: const [
                            DropdownMenuItem(
                              value: 'All',
                              child: Text(
                                'All',
                                style: TextStyle(color: Colors.white),
                              ),
                            ),
                            DropdownMenuItem(
                              value: 'Level 1',
                              child: Text(
                                'Level 1',
                                style: TextStyle(color: Colors.white),
                              ),
                            ),
                            DropdownMenuItem(
                              value: 'Level 2',
                              child: Text(
                                'Level 2',
                                style: TextStyle(color: Colors.white),
                              ),
                            ),
                            DropdownMenuItem(
                              value: 'Level 3',
                              child: Text(
                                'Level 3',
                                style: TextStyle(color: Colors.white),
                              ),
                            ),
                          ],
                          onChanged: (value) {
                            if (value == null) return;
                            setState(() {
                              _selectedThreatFilter = value;
                            });
                          },
                        ),
                      ),
                      const Spacer(),
                      Text(
                        '$visible of $total results',
                        style: const TextStyle(
                          color: Colors.white54,
                          fontSize: 12,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 12),
                  Expanded(
                    child: ListView.builder(
                      itemCount: visible,
                      itemBuilder: (context, index) {
                        final row = filteredRows[index];

                        final county =
                            row['County']?.toString() ?? 'Unknown';
                        final state =
                            row['State']?.toString() ?? '';

                        final level = _levelOf(row);

                        final probVal = row['Wind Outage Probability %'];
                        final probText = probVal == null
                            ? 'N/A'
                            : probVal.toString();

                        final customersVal =
                            row['Predicted Customers Out'];
                        final customersText = customersVal == null
                            ? 'N/A'
                            : customersVal.toString();

                        final cluster = row['Cluster']?.toString() ?? '';
                        final threatDate =
                            row['Predicted Impact Date']?.toString() ??
                                '';

                        return Container(
                          margin: const EdgeInsets.only(bottom: 8),
                          decoration: BoxDecoration(
                            color: _kPanel,
                            borderRadius: BorderRadius.circular(12),
                            border: Border.all(
                              color: _kOrange.withOpacity(0.6),
                              width: 0.8,
                            ),
                          ),
                          child: ListTile(
                            title: Text(
                              '$county, $state',
                              style: const TextStyle(
                                color: Colors.white,
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                            subtitle: Padding(
                              padding: const EdgeInsets.only(top: 4),
                              child: Text(
                                'Threat: $level   |   Cluster: $cluster\n'
                                'Wind outage prob: $probText %\n'
                                'Predicted customers out: $customersText\n'
                                'Peak impact: $threatDate',
                                style: const TextStyle(
                                  color: Colors.white70,
                                  fontSize: 12,
                                ),
                              ),
                            ),
                            trailing: const Icon(
                              Icons.chevron_right,
                              color: _kOrange,
                            ),
                            onTap: () {
                              // Future: hook drill-down here (Region â†’ State â†’ County).
                            },
                          ),
                        );
                      },
                    ),
                  ),
                ],
              ),
      ),
    );
  }
}
