﻿import "package:flutter/material.dart";
class WeatherCenterRestored extends StatelessWidget {
  const WeatherCenterRestored({super.key});
  @override
  Widget build(BuildContext context) => const SizedBox.shrink();
}
