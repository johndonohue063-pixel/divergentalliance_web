﻿import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

class WeatherCenterDrillDownScreen extends StatelessWidget {
  final Map<String, dynamic> row;

  const WeatherCenterDrillDownScreen({
    super.key,
    required this.row,
  });

  @override
  Widget build(BuildContext context) {
    final county = row["county"] ?? "";
    final state  = row["state"] ?? "";
    final gust   = row["expectedGust"] ?? 0;
    final sust   = row["expectedSustained"] ?? 0;
    final maxG   = row["maxGust"] ?? 0;
    final maxS   = row["maxSustained"] ?? 0;
    final prob   = row["probability"] ?? 0.0;
    final crews  = row["crews"] ?? 0;
    final level  = row["severity"] ?? "0";

    // Population from backend (Census). Always show it.
    final popVal = row["population"] ?? 0;
    final intPop = popVal is num ? popVal.toInt() : 0;
    final popText = NumberFormat('#,###').format(intPop);

    return Scaffold(
      backgroundColor: const Color(0xFF0E0E0E),
      appBar: AppBar(
        title: Text("$county, $state"),
        backgroundColor: Colors.black,
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          _tile("Threat Level", level.toString(), Colors.orange),
          _tile("Expected Gust", "$gust mph"),
          _tile("Expected Sustained", "$sust mph"),
          _tile("Max Gust", "$maxG mph"),
          _tile("Max Sustained", "$maxS mph"),
          _tile("Probability", "${(prob * 100).toStringAsFixed(0)}%"),
          _tile("Crew Recommendation", crews.toString()),
          _buildMetricCard('Expected Customers Out', '${row['customersOut']}'),
          _tile("Population", popText),
          const SizedBox(height: 20),
          const Text(
            "This is a detailed view for the selected county's wind analysis, "
            "outage likelihood, and threat level.",
            style: TextStyle(color: Colors.white70),
          ),
        ],
      ),
    );
  }

  Widget _tile(String label, String value, [Color? color]) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: const Color(0xFF141414),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: (color ?? Colors.grey).withOpacity(0.4),
          width: 1,
        ),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            label,
            style: const TextStyle(color: Colors.white70, fontSize: 14),
          ),
          Text(
            value,
            style: TextStyle(
              color: color ?? Colors.white,
              fontSize: 16,
              fontWeight: FontWeight.bold,
            ),
          ),
        ],
      ),
    );
  }
}

Widget _buildMetricCard(String label, String value) {
  return Card(
    margin: const EdgeInsets.symmetric(vertical: 6),
    color: const Color(0xFF141414),
    child: Padding(
      padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 14),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            label,
            style: const TextStyle(
              color: Color(0xFFBBBBBB),
              fontSize: 14,
            ),
          ),
          Text(
            value,
            style: const TextStyle(
              color: Color(0xFFFF6A00),
              fontSize: 14,
              fontWeight: FontWeight.w600,
            ),
          ),
        ],
      ),
    ),
  );
}
