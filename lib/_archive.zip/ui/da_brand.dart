import 'package:flutter/material.dart';

class DABrand {
  static const Color orange = Color(0xFFFF6600);
  static const Color black = Colors.black;
  static const Color panel = Color(0xFF121212);
  static const Color ink = Colors.white;
}
