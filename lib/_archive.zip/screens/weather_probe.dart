import "package:flutter/material.dart";
class WeatherProbe extends StatelessWidget {
  const WeatherProbe({super.key});
  @override
  Widget build(BuildContext context) => const SizedBox.shrink();
}
