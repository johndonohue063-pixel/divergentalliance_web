// Auto-generated endpoint constant
const String wxBase = 'https://da-wx-backend.onrender.com';
