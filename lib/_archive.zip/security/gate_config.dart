class GateConfig {
  static const String weatherPin = "8883";
}
