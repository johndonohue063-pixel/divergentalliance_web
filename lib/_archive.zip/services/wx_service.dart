import 'dart:convert';
import 'package:http/http.dart' as http;

class WindSummary {
  final double maxGustMph;
  final double maxSustainedMph;
  WindSummary({required this.maxGustMph, required this.maxSustainedMph});
}

/// Replace this with your backend if preferred. It returns the max gust/sustained
/// over the next `windowHours` hours using Open-Meteo (no key).
class WxService {
  static Future<WindSummary> fetchWind({
    required double lat,
    required double lon,
    required int windowHours,
  }) async {
    final uri = Uri.parse(
      'https://api.open-meteo.com/v1/forecast'
      '?latitude=$lat&longitude=$lon'
      '&hourly=windgusts_10m,windspeed_10m'
      '&windspeed_unit=mph&forecast_days=7',
    );

    final r = await http.get(uri);
    if (r.statusCode != 200) {
      throw Exception('Wind API ${r.statusCode}');
    }
    final j = jsonDecode(r.body) as Map<String, dynamic>;
    final hours = (j['hourly']?['time'] as List?)?.length ?? 0;

    final gusts = (j['hourly']?['windgusts_10m'] as List?)?.cast<num>() ?? const [];
    final sust  = (j['hourly']?['windspeed_10m'] as List?)?.cast<num>() ?? const [];

    final n = hours.clamp(0, windowHours).toDouble();
    double maxG = 0, maxS = 0.toDouble();
    for (int i = 0; i < n; i++) {
      final g = i < gusts.length ? gusts[i].toDouble() : 0;
      final s = i < sust.length  ? sust[i].toDouble()  : 0;
      if (g > maxG) maxG = g.toDouble();
      if (s > maxS) maxS = s.toDouble();
    }
    return WindSummary(maxGustMph: maxG, maxSustainedMph: maxS);
  }
}
