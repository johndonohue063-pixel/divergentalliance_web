const String apiBasePrimary = 'https://da-wx-backend.onrender.com';

const List<String> apiBaseAlternates = <String>[
  'https://da-wx-backend.onrender.com',
  'https://da-wx-backend.onrender.com',
];
